<?php
defined('BASEPATH') or exit('No direct script access allowed');
$this->load->view('partials/header');
?>

<title><?= $nama_menu . " - " . $title; ?></title>
<main id="main" class="main">

    <div class="pagetitle">
        <h1><?= $nama_menu; ?></h1>
    </div><!-- End Page Title -->

    <section class="section dashboard" style="min-height:500px">
        <div class="row">
            <!-- Left side columns -->
            <div class="col-lg-12">
                <div class="row">
                    <!-- Top Selling -->
                    <div class="col-12">
                        <div class="card top-selling">
                            <div class="card-body pb-0">
                                <div class="row mt-5">
                                </div>
                                <hr />
                                <div class="row mt-4 mb-5">
                                    <div class="col-lg-2">
                                        <label><b>TAHUN PENILAIAN</b></label>
                                    </div>
                                    <div class="col-lg-4">
                                        <select type="text" class="form-control select2" name="tahun_penilaian" id="tahun_penilaian">
                                            <option value=''>PILIH TAHUN PENILAIAN</option>
                                            <?= $opsi_tahun; ?>
                                        </select>
                                    </div>
                                </div>
                                <hr />
                                <div class="table mt-5">
                                    <input type="text" class="form-control" id="_token" name="<?php echo csrf_name(); ?>" value="<?php echo csrf_token(); ?>" style="display: none">
                                    <table id="tabel_klaster" class="table table-striped" width="100%" cellspacing="0">
                                        <tbody id="data_klaster">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <form action="review_indikator" method="POST" id="form_page_indikator">
                                <input type="text" class="form-control" id="__token" name="<?php echo csrf_name(); ?>" value="<?php echo csrf_token(); ?>" style="display: none">
                                <input type="hidden" id="klaster" name="klaster">
                            </form>

                        </div>
                    </div><!-- End Top Selling -->

                </div>
            </div><!-- End Left side columns -->
        </div>
    </section>
</main><!-- End #main -->

<?php $this->load->view('partials/footer'); ?>

<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                "<?php echo csrf_name(); ?>": $("#_token").val()
            }
        });

        $(".select2").select2();

        get_laporan();
    });

    $("#tahun_penilaian").change(function() {
        get_laporan();
    });

    function get_laporan() {
        $.ajax({
            url: "laporan/get_laporan",
            type: "POST",
            data: {
                tahun: $("#tahun_penilaian").val()
            },
            dataType: "JSON",
            success: function(data, status, xhr) {
                generate_token(xhr.getResponseHeader("<?= csrf_name(); ?>"));
                $("#data_klaster").html(data.laporan);
                tabel_klaster();
            },
            error: function(response) {
                loadingHide();
                console.log(response);
            }
        });
    }

    function tabel_klaster() {
        var t = $('#tabel_klaster')
            .dataTable({
                'destroy': true,
                'processing': true,
                "language": {
                    "processing": '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> '
                },
                'serverSide': false,
                'lengthChange': false,
                'searching': false,
                'ordering': false,
                'info': false,
                'autoWidth': false,
            });
    }
</script>