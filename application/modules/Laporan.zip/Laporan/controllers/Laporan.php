<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Laporan extends CI_Controller
{
	private $grant;
	private $ses;

	public function __construct()
	{
		parent::__construct();
		$this->load->model("laporan_m", "dbmodels");
		$this->auth->authlog();
		$this->grant 	= $this->auth->getGrant();

		$modul  		= $this->auth->modul();
		$this->ses 		= $this->session->userdata($modul);
	}

	public function index()
	{
		$data["menuSideBar"]   	= $this->auth->getMenu();
		$data["create_akses"]	= $this->grant["create"];
		$setting 				= $this->auth->getSetting();
		$icon 					= $this->auth->getIcon();

		$get_tahun = $this->dbmodels->get_tahun();
		$opsi_tahun = "";
		$tahun = date("Y");
		foreach ($get_tahun->result() as $th) {
			$selected = $th->tahun_penilaian == $tahun ? "selected" : "";
			$opsi_tahun .= "<option value='" . $this->encryption->encrypt($th->id_tahun_penilaian) . "' $selected>" . $th->tahun_penilaian . "</option>";
		}

		$data["opsi_tahun"] = $opsi_tahun;

		$data 					= array_merge($data, $setting, $icon);
		$this->load->view('laporan_v', $data);
	}

	public function noauth()
	{
		$data["menuSideBar"]	= $this->auth->getMenu();
		$setting 				= $this->auth->getSetting();
		$data 					= array_merge($data, $setting);
		$this->load->view("dist/noauth", $data);
	}

	public function tabel_klaster()
	{
		$tahun = xssInput($this->encryption->decrypt($this->input->post("tahun")));
		$table 		= 'm_klaster';

		$user 	= $this->ses["s_id_user"];
		$get_data_skpd   = $this->dbmodels->get_data_user_skpd($user);

		if ($get_data_skpd->num_rows() > 0) {
			$data_skpd = $get_data_skpd->row();
			$skpd = $data_skpd->id_skpd;
		}

		// Table's primary key
		$primaryKey = 'id_klaster';

		$columns = array(
			array(
				'db' 		=> 'a.kode_klaster',
				'dt'  		=> 0,
				'field' 	=> 'kode_klaster',
				'formatter'	=> function ($d, $row) {
					return "";
				}
			),
			array(
				'db' 		=> 'a.klaster',
				'dt' 		=> 1,
				'field' 	=> 'klaster',
				'formatter' => function ($d, $row) {
					return xssOutput($d);
				}
			),
			array(
				'db'        => 'a.id_klaster',
				'dt'        => 2,
				'field'		=> 'id_klaster',
				'formatter' => function ($d, $row) {
					$id = ($this->encryption->encrypt($d));
					$button 	= "";
					// if ($this->grant["edit"]) {
					$button 	.= "<button class='btn btn-primary' onclick='get_indikator(\"" . $id . "\")'>KLUSTER &nbsp; " . $row[0] . "</button>";
					// }
					return $button;
				}
			),
			array(
				'db' 		=> "cast(a.kode_klaster as unsigned)",
				'as'		=> 'kode_klas',
				'dt' 		=> 3,
				'field' 	=> 'kode_klas',
				'formatter' => function ($d, $row) {
					return $d;
				}
			),
		);


		$joinQuery = " FROM $table as a";
		$extraWhere = " a.id_tahun_penilaian ='$tahun'";
		$groupBy 	= NULL;


		$_REQUEST["order"][0]["column"] = 3;
		$_REQUEST["order"][0]["dir"] = "asc";

		$conn_db = db_ssp();

		echo json_encode(ssp::complex($_REQUEST, $conn_db, $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy));
	}

	public function get_laporan()
	{
		$tahun = xssInput($this->encryption->decrypt($this->input->post("tahun")));
		$data = "";

		$get_laporan = $this->dbmodels->get_laporan($tahun);

		$klaster = 0;
		$indikator = 0;
		$sub_indikator = 0;
		foreach ($get_laporan->result() as $lp) {
			if ($klaster != $lp->kode_klaster) {
				$data .= "<tr>
				<td width='10%'><strong>KLASTER " . $lp->kode_klaster . "</strong></td>
				<td colspan='5'><strong>" . strtoupper($lp->klaster) . "</strong></td>
				</tr>";
				$data .= "<tr>
							<td></td>
							<td width='10%'><strong>INDIKATOR " . $lp->kode_indikator . "</strong></td>
							<td colspan='4'><strong>" . strtoupper($lp->indikator) . "</strong></td>
						</tr>";
				$data .= "<tr>
							<td></td>
							<td></td>
							<td width='15%'><strong>SUB INDIKATOR " . $lp->kode_sub_indikator . "</strong></td>
							<td colspan='3'>" . ($lp->sub_indikator) . "</td>
						</tr>";
				$sub_indikator = $lp->kode_sub_indikator;
				$indikator = $lp->kode_indikator;
				$klaster = $lp->kode_klaster;
			} else {
				if ($indikator != $lp->kode_indikator) {
					$data .= "<tr>
							<td></td>
							<td><strong>INDIKATOR " . $lp->kode_indikator . "</strong></td>
							<td colspan='3'><strong>" . strtoupper($lp->indikator) . "</strong></td>
						</tr>";

					$data .= "<tr>
								<td></td>
								<td></td>
								<td><strong>SUB INDIKATOR " . $lp->kode_sub_indikator . "</strong></td>
								<td colspan='3'>" . ($lp->sub_indikator) . "</td>
							</tr>";
					$sub_indikator = $lp->kode_sub_indikator;
					$indikator = $lp->kode_indikator;
				} else {
					$data .= "<tr>
								<td></td>
								<td></td>
								<td><strong>SUB INDIKATOR " . $lp->kode_sub_indikator . "</strong></td>
								<td colspan='3'>" . ($lp->sub_indikator) . "</td>
							</tr>";
					$sub_indikator = $lp->kode_sub_indikator;
				}
			}

			$get_pic = $this->dbmodels->get_pic_subindikator($lp->id_sub_indikator);
			foreach ($get_pic->result() as $pic) {
				$data .= "<tr>
								<td></td>
								<td></td>
								<td></td>
								<td width='30%'><strong>" . $pic->skpd . "</strong></td>
								<td colspan='2'>
									<strong>Jawaban :</strong>
									</br>" . ($pic->keterangan) . "
									</br><strong>Bukti Dukung / Lampiran :</strong>
									</br><a href='" . $this->auth->path_file() . $pic->file_bukti . "' class='link-primary' target='_blank'>" . $pic->file_bukti . "</a>
								</td>
							</tr>";
			}
		}

		$obj = [
			"laporan" => $data
		];

		echo json_encode($obj);
	}
}
