<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Laporan_m extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    public function get_data_user_skpd($user)
    {
        return $this->db->get_where("m_user_skpd", ["id_user" => $user]);
    }

    public function get_tahun()
    {
        $params_where = [
            "aktif" => 1
        ];
        return $this->db->get_where("m_tahun_penilaian", $params_where);
    }

    public function get_laporan($tahun)
    {
        return $this->db->query(
            "SELECT a.kode_klaster, a.klaster, b.kode_indikator, b.indikator,c.kode_sub_indikator, c.sub_indikator, c.id_sub_indikator
            FROM m_klaster a
            INNER JOIN m_indikator b ON a.id_klaster=b.id_klaster
            INNER JOIN m_sub_indikator c ON b.id_indikator=c.id_indikator AND c.aktif=1
            WHERE
            a.aktif = 1 AND b.aktif=1 AND a.id_tahun_penilaian='$tahun'
            ORDER BY 
            cast(a.kode_klaster as unsigned) ASC, 
            cast(b.kode_indikator as unsigned) ASC,
            cast(c.kode_sub_indikator as unsigned) ASC"
        );
    }

    public function get_pic_subindikator($id_sub_indikator)
    {
        return $this->db->query(
            "SELECT a.*, b.skpd
            FROM detail_pic_subindikator a
            INNER JOIN m_skpd b ON a.id_skpd=b.id_skpd
            WHERE a.id_sub_indikator= '$id_sub_indikator'"
        );
    }
}
